ROZVOJ DETÍ S POROZUMENÍM – štartovací HTML web

Súbory:
- index.html: hlavná stránka v slovenčine

PRED ZVEREJNENÍM:
1. V index.html nájdite DOPLNTE-EMAIL a nahraďte ho svojou e-mailovou adresou (v odkaze aj v zobrazenom texte).
2. Upravte informáciu o pôsobnosti, názvy a texty tak, aby presne zodpovedali vašej činnosti a kvalifikácii.
3. Kontaktný formulár je zatiaľ iba ukážka a správy neodosiela. Pred použitím ho treba prepojiť s formulárovou službou alebo nahradiť e-mailovým odkazom.
4. Nezverejňujte citlivé údaje ani fotografie detí bez príslušného súhlasu.

ZVEREJNENIE CEZ NETLIFY DROP:
1. Rozbaľte ZIP súbor do priečinka.
2. Otvorte https://app.netlify.com/drop
3. Nahrajte rozbalený priečinok (alebo ho presuňte do okna stránky).
4. Postupujte podľa pokynov. Uložte si pridelenú webovú adresu.
5. Pri ďalšej úprave nahrajte aktualizovanú verziu stránky.

Tento web je statická HTML stránka. Hosting môže byť bezplatný, no vlastná doména (napr. rozvojdeti.sk) sa zvyčajne kupuje samostatne.
